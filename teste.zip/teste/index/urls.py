from django.urls import path
from django.conf.urls import url

from .views import *

urlpatterns = [
    path('',index,name='index'),
    path ( 'email_list' , email_list , name='email_list' ) ,
    path('domain_list',domain_list,name='domain_list'),
    path ('country_list' ,country_list, name='country_list'),

    path('add_email',add_email,name='add_email'),
    path('add_country',add_country,name='add_country'),
    path ('add_domain' ,add_domain, name='add_domain'),

    path('edit_email/<int:pk>', edit_email, name='edit_email'),
    path('delete_email/<int:pk>', delete_email, name='delete_email'),
    
    path('search',search,name='search'),
]