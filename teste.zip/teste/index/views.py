from .forms import *
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from .filter import *
from django.db.models import Count
from django.db.models import Q

def search(request):
    template = 'search.html'
    email_list = Email.objects.all()
    search_filter = SearchFilter(request.GET,queryset=email_list)

    context = {'filter':search_filter}

    return render(request,template,context)

def index(request):
    template = 'index.html'

    emails = Email.objects.filter()
    email_count = Email.objects.count()
    domain_count = Domain.objects.count()
    domains = Domain.objects.all()
    country_count = Country.objects.count()
    countries = Country.objects.all()
    argentina_count = Email.objects.filter(country_id=3).count()
    brasil_count = Email.objects.filter(country_id=2).count()
    mex_count = Email.objects.filter(country_id=4).count()
    geral_count = Email.objects.filter(country_id=1).count()
    err_domain = Email.objects.filter(domain=6).count()
    err_br = Email.objects.filter(Q(country_id=2) & (Q(domain=6))).count()
    err_ar = Email.objects.filter(Q(country_id=3) & (Q(domain=6))).count()
    err_mx = Email.objects.filter(Q(country_id=4) & (Q(domain=6))).count()
    err_geral = Email.objects.filter(Q(country_id=1) & (Q(domain=6))).count()

    paginator = Paginator(emails,10)
    page = request.GET.get('page') 
    try:
        emails = paginator.page(page)
    except PageNotAnInteger:
        emails = paginator.page(1)
    except EmptyPage:
        emails = paginator.page(paginator.num_pages)

    context={
            'emails': emails,
            'email_count':email_count,
            'domain_count': domain_count ,
            'domains' : domains,
            'country_count': country_count,
            'countries':countries,
            'argentina_count':argentina_count,
            'brasil_count':brasil_count ,
            'mex_count':mex_count,
            'geral_count':geral_count,
            'err_domain':err_domain,
            'err_br':err_br,
            'err_ar':err_ar,
            'err_mx':err_mx,
            'err_geral':err_geral,       
      }
    return render(request,template,context)

def email_list(request): 
    template = 'email_list.html'
    email_count = Email.objects.count() 

    emails = Email.objects.filter()
    email_count = Email.objects.count()
    domain_count = Domain.objects.count()
    domains = Domain.objects.all()
    country_count = Country.objects.count()
    countries = Country.objects.all()
    argentina_count = Email.objects.filter(country_id=3).count()
    brasil_count = Email.objects.filter(country_id=2).count()
    mex_count = Email.objects.filter(country_id=4).count()
    geral_count = Email.objects.filter(country_id=1).count()
    err_domain = Email.objects.filter(domain=6).count()
    err_br = Email.objects.filter(Q(country_id=2) & (Q(domain=6))).count()
    err_ar = Email.objects.filter(Q(country_id=3) & (Q(domain=6))).count()
    err_mx = Email.objects.filter(Q(country_id=4) & (Q(domain=6))).count()
    err_geral = Email.objects.filter(Q(country_id=1) & (Q(domain=6))).count()

    paginator = Paginator(emails,10)
    page = request.GET.get('page') 

    try:
        emails = paginator.page(page)
    except PageNotAnInteger:
        emails = paginator.page(1)
    except EmptyPage:
        emails = paginator.page(paginator.num_pages)

    context={
            'emails': emails,
            'email_count':email_count,
            'domain_count': domain_count ,
            'domains' : domains,
            'country_count': country_count,
            'countries':countries,
            'argentina_count':argentina_count,
            'brasil_count':brasil_count ,
            'mex_count':mex_count,
            'geral_count':geral_count,
            'err_domain':err_domain,
            'err_br':err_br,
            'err_ar':err_ar,
            'err_mx':err_mx,
            'err_geral':err_geral,       
      }

    return render(request,template,context)

def domain_list(request):
    template = 'domain_list.html'

    emails = Email.objects.filter()
    email_count = Email.objects.count()
    domain_count = Domain.objects.count()
    domains = Domain.objects.all()
    country_count = Country.objects.count()
    countries = Country.objects.all()
    argentina_count = Email.objects.filter(country_id=3).count()
    brasil_count = Email.objects.filter(country_id=2).count()
    mex_count = Email.objects.filter(country_id=4).count()
    geral_count = Email.objects.filter(country_id=1).count()
    err_domain = Email.objects.filter(domain=6).count()
    err_br = Email.objects.filter(Q(country_id=2) & (Q(domain=6))).count()
    err_ar = Email.objects.filter(Q(country_id=3) & (Q(domain=6))).count()
    err_mx = Email.objects.filter(Q(country_id=4) & (Q(domain=6))).count()
    err_geral = Email.objects.filter(Q(country_id=1) & (Q(domain=6))).count()

    context={
            'emails': emails,
            'email_count':email_count,
            'domain_count': domain_count ,
            'domains' : domains,
            'country_count': country_count,
            'countries':countries,
            'argentina_count':argentina_count,
            'brasil_count':brasil_count ,
            'mex_count':mex_count,
            'geral_count':geral_count,
            'err_domain':err_domain,
            'err_br':err_br,
            'err_ar':err_ar,
            'err_mx':err_mx,
            'err_geral':err_geral,       
      }

    return render(request,template,context)

def country_list(request):
    template = 'country_list.html'

    emails = Email.objects.filter()
    email_count = Email.objects.count()
    domain_count = Domain.objects.count()
    domains = Domain.objects.all()
    country_count = Country.objects.count()
    countries = Country.objects.all()
    argentina_count = Email.objects.filter(country_id=3).count()
    brasil_count = Email.objects.filter(country_id=2).count()
    mex_count = Email.objects.filter(country_id=4).count()
    geral_count = Email.objects.filter(country_id=1).count()
    err_domain = Email.objects.filter(domain=6).count()


    context={
            'emails': emails,
            'email_count':email_count,
            'domain_count': domain_count ,
            'domains' : domains,
            'country_count': country_count,
            'countries':countries,
            'argentina_count':argentina_count,
            'brasil_count':brasil_count ,
            'mex_count':mex_count,
            'geral_count':geral_count,
            'err_domain':err_domain,
            
      }

    return render(request,template,context)

def add_item(request,cls):
    if request.method == 'POST':
        form = cls(request.POST)

        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form=cls()
    return render(request,'add_country.html',{'form':form})

def add_country(request):
    return add_item(request, CountryForm)

def add_domain(request):
    return add_item(request, DomainForm)

def add_email(request):
    return add_item(request, EmailForm)

def edit_item(request, pk, model, cls):
    item = get_object_or_404(model, pk=pk)
    if request.method == "POST":
        form = cls(request.POST, instance=item)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = cls(instance=item)

    return render(request, 'edit_email.html', {'form': form})

def edit_country(request, pk):
    return edit_item(request, pk, Country, CountryForm)

def edit_domain(request, pk):
    return edit_item(request, pk, Domain, DomainForm)

def edit_email(request, pk):
    return edit_item(request, pk, Email, EmailForm)

def delete_country(request, pk):
    
    template = 'index.html'
    Country.objects.filter(pk=pk).delete()

    items = Country.objects.all()

    context = {
        'items': items,
    }

    return render(request, template, context)

def delete_domain(request, pk):

    template = 'index.html'
    Domain.objects.filter(pk=pk).delete()

    items = Domain.objects.all()

    context = {
        'items': items,
    }

    return render(request, template, context)

def delete_email(request, pk):

    template = 'index.html'
    Email.objects.filter(id=pk).delete()

    items = Email.objects.all()

    context = {
        'items': items,
    }

    return render(request, template, context)

